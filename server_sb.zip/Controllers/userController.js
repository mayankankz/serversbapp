const { async } = require('q');
const User = require('../Models/userModel');
const db = require('../Utill/database');
let bcrypt = require('bcryptjs');
const { hashPassword } = require('../Utill/hashVerifyPassward');
const school = require('../Models/schoolModel');
const student = require('../Models/studentsData');
const { validationResult,  } = require('express-validator');
const nodemailer = require('nodemailer');


exports.createUser = async (req, res) => {
    const { username, password, Schoolname, schoolcode, email, validationoptions } = req.body;
  
    if (!username || !password || !Schoolname || !schoolcode || !email || JSON.parse(validationoptions).length === 0) {
      return res.status(400).json({
        status: 'failed',
        error: 'All fields are required',
      });
    }
  
    const hashedPass = await hashPassword(password);
    try {
      // Check if user already exists with the same school code and email
      const existingUser = await User.findOne({ where: { schoolcode, email } });
      if (existingUser) {
        return res.status(400).json({
          status: 'failed',
          error: 'User already exists with the same school code and email',
        });
      }
      // Create a new user
      const user = await User.create({ username, password: hashedPass, Schoolname, schoolcode, email, validationoptions, isAdmin: false });
      if (user) {
        const transporter = nodemailer.createTransport({
            // Configure your email provider settings here
            service: 'gmail',
            auth: {
              user: 'mayankgirigoswami2212@gmail.com',
              pass: 'uquzgdjctllfibup',
            },
          });
    
          const mailOptions = {
            from: 'Mayankgirigoswami2212@gmail.com',
            to: email,
            subject: 'Account Created',
            html: `<!DOCTYPE html> <html> <head> <meta charset="utf-8" /> <meta http-equiv="X-UA-Compatible" content="IE=edge" /> <title>User Registration</title> <meta name="viewport" content="width=device-width, initial-scale=1"> <style>/* Reset styles */body,h1,h2,h3,p {margin: 0;padding: 0;}/* Container */.container {max-width: 600px;margin: 0 auto;padding: 20px;font-family: Arial, sans-serif;background: #cd2a26;}/* Header */.header {text-align: center;margin-bottom: 20px;}/* Logo */.logo {display: flex;justify-content: center;max-width: 100px;margin-bottom: 20px;background-color: #000000;}/* Title */.title {color: #ffffff;font-size: 28px;margin-bottom: 20px;}/* Content */.content {background-color: #000000;padding: 20px;border-radius: 5px;}/* Username */.username {color: #ffffff;font-size: 24px;margin-bottom: 10px;}/* Credentials */.credentials {margin-bottom: 20px;}.credentials li {list-style: none;margin-bottom: 5px;color: #ffffff;}.credentials strong {font-weight: bold;}/* Contact */.contact {margin-bottom: 20px;}/* Footer */.footer {text-align: center;margin-top: 20px;color: #ffffff;}/* Button */.button {display: inline-block;background-color: #4CAF50;color: #fff;padding: 10px 20px;border-radius: 4px;text-decoration: none;}</style> </head> <body> <div class="container"> <div class="header"> <div class="logo"> <img src="1.png" alt="Logo" style="max-width: 100%; height: auto;"> </div> <h1 class="title">Welcome to Our Platform</h1> </div> <div class="content"> <p class="username">Dear <strong>${username}</strong>,</p> <p style="color: #ffffff;">Thank you for registering with us!</p> <div class="credentials"> <p style="color: #ffffff;">Your account has been created successfully. Here are your login credentials:</p> <ul> <li><strong>Username:</strong> <span style="color: #ffffff;">${username}</span></li> <li><strong>Password:</strong> <span style="color: #ffffff;">${password}</span></li> </ul> </div> <div class="contact"> <p style="color: #ffffff;">If you have any questions or need further assistance, please don't hesitate to contact us.</p> </div> <p style="color: #ffffff;">Best regards,<br />Admin</p> <div class="footer"> <p>&copy; 2023 SB ONLINE SERVICES. All rights reserved.</p> </div> </div> </div> </body> </html>`,
          };
    
          transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
              console.error('Error sending email:', error);
            } else {
              console.log('Email sent:', info.response);
            }
          });
  
        return res.status(201).json({
          status: 'success',
          user,
        });
      } else {
        return res.status(400).json({
          status: 'failed',
          error: '',
        });
      }
    } catch (error) {
      return res.status(400).json({
        status: 'failed',
        error: error.errors.map((e) => e.message),
      });
    }
  };


exports.createSchool = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(422).json({ errors: errors.array() });
    }

    const { schoolname, schoolcode } = req.body;

    try {

        // Check if school code already exists
        const existingSchool = await school.findOne({ where: { schoolcode } });
        if (existingSchool) {
            return res.status(400).json({
                status: 'failed',
                error: 'School code already exists',
            });
        }
        const newSchool = await school.create({ schoolname, schoolcode });
        const message = newSchool
            ? { status: 'success', data: newSchool }
            : { status: 'failed', error: 'Failed to create new school' };
        res.status(201).json(message);
    } catch (error) {
        res.status(400).json({
            status: 'failed',
            error: error.errors?.map((e) => e.message)
        });
    }
}


exports.findUserByID = async (req, res) => {
    const { id } = req.body;
    try {
        const user = await User.findByPk(id);
        if (user) {
            res.status(200).json({
                status: 'success',
                user: {
                    name: user.username,
                    email: user.email,
                    school: user.Schoolname,
                    code: user.schoolcode
                }
            })
        } else {
            res.status(404).json({
                status: 'error',
                error: 'User not found'
            })
        }
    } catch (error) {
        res.status(500).json({
            status: 'Error',
            error: 'Somthing Went Wrong'
        })
    }

}


exports.getAllSchools = async (req, res) => {
    try {
        const schools = await school.findAll();
        if (schools) {
            res.status(200).json({
                status: 'success',
                schools
            })
        } else {
            res.status(404).json({
                status: 'error',
                error: 'schools not found'
            })
        }
    } catch (error) {
        res.status(500).json({
            status: 'Error',
            error: 'Somthing Went Wrong'
        })
    }

}


exports.getStudentsData = async (req, res) => {
    const {classname,schoolname} = req.body;

    if(!classname || !schoolname) res.status(404).json({error : 'All fields required!!!!'})

    try {
        const students = await student.findAll({
            where: {
              schoolname: schoolname,
              class: classname
            }
          });
        if (students) {
            res.status(200).json({
                status: 'success',
                students
            })
        } else {
            res.status(404).json({
                status: 'error',
                error: 'students not found'
            })
        }
    } catch (error) {
        res.status(500).json({
            status: 'Error',
            error: 'Somthing Went Wrong'
        })
    }

}

exports.getStudentAllData = async (req, res) => {
    //const {classname,schoolname} = req.body;

    try {
        const students = await student.findAll();
        if (students) {
            res.status(200).json({
                status: 'success',
                students
            })
        } else {
            res.status(404).json({
                status: 'error',
                error: 'students not found'
            })
        }
    } catch (error) {
        res.status(500).json({
            status: 'Error',
            error: 'Somthing Went Wrong'
        })
    }

}

exports.getStudentDataBySchoolCode = async (req, res) => {
    const { schoolCode } = req.params;


    try {
        const students = await student.findAll({
            where: {
                schoolcode: schoolCode,
            },
          });
        if (students) {
            res.status(200).json({
                status: 'success',
                students
            })
        } else {
            res.status(404).json({
                status: 'error',
                error: 'students not found'
            })
        }
    } catch (error) {
        res.status(500).json({
            status: 'Error',
            error: 'Somthing Went Wrong'
        })
    }

}
// exports.getStudentDataBySchoolCode = async (req, res) => {
//     const { schoolCode } = req.params;
  
//     try {
//       const studentInfo = await student.findAll({
//         where: {
//             schoolcode: schoolCode,
//         },
//       });
//       if (studentInfo) {
//         res.status(200).json({
//           status: 'success',
//           studentInfo,
//         });
//       } else {
//         res.status(404).json({
//           status: 'error',
//           error: 'students not found',
//         });
//       }
//     } catch (error) {
//       res.status(500).json({
//         status: 'Error',
//         error: 'Something Went Wrong',
//       });
//     }
//   };
  
exports.updateStudentData = async (req, res) => {
    const { id } = req.params; // Assuming the student ID is passed as a parameter
    const updatedData = req.body;
  
    try {
      const studentinfo = await student.findByPk(id); // Assuming you have a model called "Student"
  
      if (studentinfo) {
        await studentinfo.update(updatedData);
        res.status(200).json({
          status: 'success',
          message: 'Student data updated successfully',
          updatedData: studentinfo
        });
      } else {
        res.status(404).json({
          status: 'error',
          error: 'Student not found'
        });
      }
    } catch (error) {
      res.status(500).json({
        status: 'error',
        error: 'Something went wrong while updating student data'
      });
    }
  };
  